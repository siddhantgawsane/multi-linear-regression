Regression with the IRIS dataset
Siddhant Gawsane, 1001231597

code file: regression.py
report: Regression-report.odt

Requirements:
python 2.7.12
matplotlib 2.0.2

Execution:
To run the program, simply type 'python path/to/file/regression.py'

Sample output:
siddhant@siddhant-Ideapad-Z570:~/Workspace/ML$ python regression.py 
Scores: [0.10948486747940578, 0.1080891091229943, 0.12783585312851387, 0.10509371268173848, 0.11025596284755279]
Mean RMSE: 0.112
